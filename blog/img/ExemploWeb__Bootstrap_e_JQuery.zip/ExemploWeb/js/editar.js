//Só carrega quando o HTML estiver pronto.
//window.onload = function(){
$(document).ready(function() {
	if(window.indexedDB) {
		var db = null;
		var objBanco = window.indexedDB.open("despesasApp", 1);
		objBanco.onsuccess = function(evento){
			console.log("Conexão realizada com sucesso!");
			db = evento.target.result;
			
			//CONSULTA
			var tx = db.transaction(["despesas"], "readonly");
			var despesaStore = tx.objectStore("despesas");
		
		
			var iCodigo = parseInt(getUrlParameter("codigo"));
			console.log(iCodigo);
			
			var objConsulta = despesaStore.get(iCodigo);
			objConsulta.onsuccess = function() {
				var registro = objConsulta.result;
				console.log(registro);
				$("#data").val(registro.data);
				$("#tipo").val(registro.tipo);
				$("#descricao").val(registro.descricao);
				$("#valor").val(registro.valor);
			};
			
			//Atualizar no banco de dados
			$("#botao").click(function(){
				//JSON
				var despesa = {	data: 		$("#data").val(),
								tipo: 		$("#tipo").val(),
								descricao: 	$("#descricao").val(),
								valor: 		parseFloat($("#valor").val()),
								codigo: 	iCodigo};
				console.log(despesa);
				var tx = db.transaction(["despesas"], "readwrite");
				var despesaStore = tx.objectStore("despesas");
				despesaStore.put(despesa);
				window.location.href="index.html";
			});
		}
	}
});


