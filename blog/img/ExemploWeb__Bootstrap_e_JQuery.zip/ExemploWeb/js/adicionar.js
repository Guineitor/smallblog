//Só carrega quando o HTML estiver pronto.
window.onload = function(){
	//Inicialização do banco de dados
	var botao = document.getElementById("botao");
	
	if(window.indexedDB) {
		var db = null;
		var objBanco = window.indexedDB.open("despesasApp", 1);
		objBanco.onsuccess = function(evento){
			console.log("Conexão realizada com sucesso!");
			db = evento.target.result;
		}
		
		objBanco.onerror = function(evento){
			console.log("Erro na conexão com banco de dados");
		}
		
		objBanco.onupgradeneeded = function(evento){
			db = evento.target.result;
			var objDespesas = db.createObjectStore("despesas", 
			{ keyPath: "codigo", autoIncrement: true });
		}
		
		//Quando o usuário clicar no botão..
		botao.onclick = function() {
			//Capturar os valores do formulário..
			var sData = 
			document.getElementById("data").value;
			var sTipo = 
			document.getElementById("tipo").value;
			var sDescricao = 
			document.getElementById("descricao").value;
			var fValor = 
			parseFloat(document.getElementById("valor").value);		
			console.log(sData+sTipo+sDescricao+fValor);
			
			//JSON
			var despesa = {data: sData,
						   tipo: sTipo,
						   descricao: sDescricao,
						   valor: fValor};
			console.log(despesa);
			
			var tx = db.transaction(["despesas"], "readwrite");
			var despesaStore = tx.objectStore("despesas");
			despesaStore.put(despesa);
			
			window.location.href = "index.html";
		}
	} else {
		console.log("Banco de dados IndexedDB não suportado");
	}

	//Comando para registrar no console
	console.log("Alô mundo!");

	/*
	Chamar o botão de "Adicionar despesa"
	*/

	//Quando o usuário passar o mouse no botão..
	botao.onmouseover = function(){
		botao.value = "OLÁ!";
	}

	//Quando o usuário tirar o mouse no botão..
	botao.onmouseout = function(){
		botao.value = "Adicionar despesa";
	}	
	

	
	
}