//Só carrega quando o HTML estiver pronto.
//window.onload = function(){
$(document).ready(function() {
	if(window.indexedDB) {
		var db = null;
		var objBanco = window.indexedDB.open("despesasApp", 1);
		objBanco.onsuccess = function(evento){
			console.log("Conexão realizada com sucesso!");
			var db = evento.target.result;
			
			//CONSULTA
			var tx = db.transaction(["despesas"], "readonly");
			var despesaStore = tx.objectStore("despesas");
		
		
			var iCodigo = parseInt(getUrlParameter("codigo"));
			console.log(iCodigo);
			
			var objConsulta = despesaStore.get(iCodigo);
			objConsulta.onsuccess = function() {
				var registro = objConsulta.result;
				console.log(registro);
				$("#data").html(registro.data.substring(8,10)+"/"+
					registro.data.substring(5,7)+"/"+
					registro.data.substring(0,4));
				$("#tipo").html(registro.tipo);
				$("#descricao").html(registro.descricao);
				$("#valor").html(("R$ "+registro.valor).replace(".",","));
			};
			
			//Atualizar no banco de dados
			$("#botao").click(function(){
				var tx = db.transaction(["despesas"], "readwrite");
				var despesaStore = tx.objectStore("despesas");
				despesaStore.delete(iCodigo);
				window.location.href="index.html";
			});
		}
	}
});


